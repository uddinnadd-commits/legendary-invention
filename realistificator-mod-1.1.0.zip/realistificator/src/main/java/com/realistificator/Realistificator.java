package com.realistificator;

import net.fabricmc.api.ModInitializer;

public class Realistificator implements ModInitializer {
    public static final String MOD_ID = "realistificator";

    @Override
    public void onInitialize() {
        ModEntities.init();
        ModItems.init();
    }
}
