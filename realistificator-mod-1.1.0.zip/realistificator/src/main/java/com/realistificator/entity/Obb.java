package com.realistificator.entity;

import net.minecraft.world.phys.AABB;
import org.joml.Vector3d;

import java.util.ArrayList;
import java.util.List;

/** Oriented bounding box + separating-axis test. Axes must be unit length and are treated as read-only. */
public final class Obb {
    public static final Vector3d[] IDENTITY = {new Vector3d(1, 0, 0), new Vector3d(0, 1, 0), new Vector3d(0, 0, 1)};

    public final Vector3d c;
    public final Vector3d[] ax;
    public final double[] h;

    public Obb(Vector3d center, Vector3d[] axes, double hx, double hy, double hz) {
        this.c = center;
        this.ax = axes;
        this.h = new double[]{hx, hy, hz};
    }

    public static Obb ofAabb(AABB b) {
        return new Obb(new Vector3d((b.minX + b.maxX) * 0.5, (b.minY + b.maxY) * 0.5, (b.minZ + b.maxZ) * 0.5), IDENTITY,
                (b.maxX - b.minX) * 0.5, (b.maxY - b.minY) * 0.5, (b.maxZ - b.minZ) * 0.5);
    }

    /** Result of a SAT test: normal points from b towards a. */
    public record Sat(Vector3d normal, double depth) {}

    public static Sat sat(Obb a, Obb b) {
        Vector3d t = new Vector3d(a.c).sub(b.c);
        double bestScore = Double.MAX_VALUE;
        double bestDepth = 0;
        Vector3d bestN = null;

        for (int k = 0; k < 15; k++) {
            Vector3d axis;
            boolean edge = k >= 6;
            if (k < 3) axis = a.ax[k];
            else if (k < 6) axis = b.ax[k - 3];
            else {
                int i = (k - 6) / 3, j = (k - 6) % 3;
                axis = new Vector3d(a.ax[i]).cross(b.ax[j]);
                double len = axis.length();
                if (len < 1.0E-6) continue;
                axis.div(len);
            }
            double ra = 0, rb = 0;
            for (int m = 0; m < 3; m++) {
                ra += a.h[m] * Math.abs(a.ax[m].dot(axis));
                rb += b.h[m] * Math.abs(b.ax[m].dot(axis));
            }
            double dist = t.dot(axis);
            double overlap = ra + rb - Math.abs(dist);
            if (overlap <= 0) return null;
            double score = edge ? overlap * 1.05 + 0.002 : overlap; // prefer face contacts over edge-edge
            if (score < bestScore) {
                bestScore = score;
                bestDepth = overlap;
                bestN = new Vector3d(axis);
                if (dist < 0) bestN.negate();
            }
        }
        return bestN == null ? null : new Sat(bestN, bestDepth);
    }

    public boolean contains(Vector3d p, double tol) {
        Vector3d d = new Vector3d(p).sub(c);
        for (int i = 0; i < 3; i++) {
            if (Math.abs(d.dot(ax[i])) > h[i] + tol) return false;
        }
        return true;
    }

    public Vector3d[] vertices() {
        Vector3d[] out = new Vector3d[8];
        int n = 0;
        for (int sx = -1; sx <= 1; sx += 2)
            for (int sy = -1; sy <= 1; sy += 2)
                for (int sz = -1; sz <= 1; sz += 2) {
                    out[n++] = new Vector3d(c)
                            .fma(sx * h[0], ax[0]).fma(sy * h[1], ax[1]).fma(sz * h[2], ax[2]);
                }
        return out;
    }

    /** Contact points between a and b: vertices of either box lying inside the other. n points from b to a. */
    public static List<Vector3d> contactPoints(Obb a, Obb b, Vector3d n) {
        List<Vector3d> pts = new ArrayList<>();
        for (Vector3d v : a.vertices()) if (b.contains(v, 0.02)) pts.add(v);
        for (Vector3d v : b.vertices()) if (a.contains(v, 0.02)) pts.add(v);
        if (pts.isEmpty()) {
            // edge-edge or numerical corner case: use the deepest face/edge of a along -n
            Vector3d[] av = a.vertices();
            double min = Double.MAX_VALUE;
            for (Vector3d v : av) min = Math.min(min, v.dot(n));
            Vector3d sum = new Vector3d();
            int cnt = 0;
            for (Vector3d v : av) {
                if (v.dot(n) < min + 0.02) { sum.add(v); cnt++; }
            }
            pts.add(sum.div(cnt));
        }
        return pts;
    }
}
