package com.realistificator;

import com.realistificator.item.RealistificatorItem;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;

public final class ModItems {
    private static final ResourceKey<Item> REALISTIFICATOR_KEY =
            ResourceKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(Realistificator.MOD_ID, "realistificator_3000"));

    public static final Item REALISTIFICATOR_3000 = Registry.register(
            BuiltInRegistries.ITEM,
            REALISTIFICATOR_KEY,
            new RealistificatorItem(new Item.Properties().setId(REALISTIFICATOR_KEY).stacksTo(1)));

    private ModItems() {}

    public static void init() {
        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.TOOLS_AND_UTILITIES)
                .register(output -> output.accept(REALISTIFICATOR_3000));
    }
}
