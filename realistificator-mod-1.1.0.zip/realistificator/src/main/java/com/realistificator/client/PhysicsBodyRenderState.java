package com.realistificator.client;

import com.realistificator.entity.PhysicsCell;
import net.minecraft.client.renderer.block.BlockModelRenderState;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import org.joml.Quaternionf;

import java.util.ArrayList;
import java.util.List;

public class PhysicsBodyRenderState extends EntityRenderState {
    public List<PhysicsCell> cells = List.of();
    /** One resolved block model per cell (26.1+ no longer has submitBlock). */
    public final List<BlockModelRenderState> blocks = new ArrayList<>();
    public Quaternionf rotation = new Quaternionf();
    public float comX, comY = 0.5f, comZ;
}
