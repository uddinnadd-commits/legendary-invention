package com.realistificator.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.realistificator.entity.PhysicsBodyEntity;
import com.realistificator.entity.PhysicsCell;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.block.BlockDisplayContext;
import net.minecraft.client.renderer.block.BlockModelRenderState;
import net.minecraft.client.renderer.block.BlockModelResolver;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/**
 * Draws each cell as a normal block model. The pose stack is already at the entity position, which is the
 * body's centre of mass, so we rotate there and then offset each cell relative to the centre of mass.
 */
public class PhysicsBodyRenderer extends EntityRenderer<PhysicsBodyEntity, PhysicsBodyRenderState> {
    private static final BlockDisplayContext DISPLAY_CONTEXT = BlockDisplayContext.create();

    private final BlockModelResolver blockResolver;

    public PhysicsBodyRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.blockResolver = context.blockModelResolver();
    }

    @Override
    public PhysicsBodyRenderState createRenderState() {
        return new PhysicsBodyRenderState();
    }

    @Override
    public void extractRenderState(PhysicsBodyEntity entity, PhysicsBodyRenderState state, float partialTick) {
        super.extractRenderState(entity, state, partialTick);
        state.cells = entity.getCells();
        state.rotation = entity.getRenderRotation(partialTick);
        Vec3 com = entity.getCom();
        state.comX = (float) com.x;
        state.comY = (float) com.y;
        state.comZ = (float) com.z;

        while (state.blocks.size() < state.cells.size()) state.blocks.add(new BlockModelRenderState());
        while (state.blocks.size() > state.cells.size()) state.blocks.removeLast();
        for (int i = 0; i < state.cells.size(); i++) {
            blockResolver.update(state.blocks.get(i), state.cells.get(i).state(), DISPLAY_CONTEXT);
        }
    }

    @Override
    public void submit(PhysicsBodyRenderState state, PoseStack poseStack, SubmitNodeCollector collector, CameraRenderState camera) {
        try {
            poseStack.pushPose();

            // PoseStack.mulPose(Quaternionf) is gone in 26.3, so apply the orientation as Y, X, Z rotations
            // (a quaternion is exactly q = Ry * Rx * Rz, which is what getEulerAnglesYXZ returns).
            Vector3f euler = state.rotation.getEulerAnglesYXZ(new Vector3f());
            poseStack.rotate(Axis.YP, euler.y);
            poseStack.rotate(Axis.XP, euler.x);
            poseStack.rotate(Axis.ZP, euler.z);

            for (int i = 0; i < state.cells.size() && i < state.blocks.size(); i++) {
                PhysicsCell cell = state.cells.get(i);
                poseStack.pushPose();
                // lattice centre is (x, y + 0.5, z); a block model's origin is its min corner (-0.5 from centre)
                poseStack.translate(cell.x() - state.comX - 0.5f, cell.y() - state.comY, cell.z() - state.comZ - 0.5f);
                state.blocks.get(i).submit(poseStack, collector, state.lightCoords, OverlayTexture.NO_OVERLAY, state.outlineColor);
                poseStack.popPose();
            }
            poseStack.popPose();
        } catch (Exception ignored) {
            // a rendering hiccup must never crash the game; skip this frame's draw
        }
        super.submit(state, poseStack, collector, camera);
    }
}
